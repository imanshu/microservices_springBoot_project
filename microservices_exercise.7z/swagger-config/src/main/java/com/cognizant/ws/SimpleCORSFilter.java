package com.cognizant.ws;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class SimpleCORSFilter implements Filter {
	private static final String ACCESS_CONTROL_REQUEST_METHOD = "Access-Control-Request-Method";
	
	@Value("${spring.swagger.headerFilters}")
	private String filters;
	
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		//check if the incoming method type is option then only set this response header
		HttpServletResponse response = (HttpServletResponse) res;
		response.setHeader("Access-Control-Allow-Origin", "*");
		response.setHeader("Access-Control-Allow-Methods", "POST, GET, PATCH, OPTIONS, DELETE, PUT");
		response.setHeader("Access-Control-Max-Age","86400");
		response.setHeader("Access-Control-Allow-Credentials","true");
		if(filters.isEmpty()){
			response.setHeader("Access-Control-Allow-Headers", "accept, content-type, authorization,x-requested-with");
		}
		else{
			String tempFilters="accept, content-type, authorization,x-requested-with,";
			response.setHeader("Access-Control-Allow-Headers", tempFilters+filters);
		}
		response.addHeader("Access-Control-Expose-Headers", "resultCount,location");
		chain.doFilter(req, res);
	}
	public void init(FilterConfig filterConfig) {}
	public void destroy() {}
}
