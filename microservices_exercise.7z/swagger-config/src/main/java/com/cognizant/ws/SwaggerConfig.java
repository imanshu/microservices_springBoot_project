package com.cognizant.ws;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.mangofactory.swagger.configuration.SpringSwaggerConfig;
import com.mangofactory.swagger.models.dto.ApiInfo;
import com.mangofactory.swagger.plugin.EnableSwagger;
import com.mangofactory.swagger.plugin.SwaggerSpringMvcPlugin;

@Configuration
@Component
@EnableSwagger
public class SwaggerConfig {

	@Value("${spring.swagger.root.request.mapping}")
	private String controllerPath;
	

	@Value("${spring.swagger.api.name}")
	private String apiName;

	@Value("${spring.swagger.api.description}")
	private String apiDescription;

	private SpringSwaggerConfig springSwaggerConfig;

	@Autowired
	public void setSpringSwaggerConfig(SpringSwaggerConfig springSwaggerConfig) {
		this.springSwaggerConfig = springSwaggerConfig;
	}

	@Bean
	public SwaggerSpringMvcPlugin customImplementation() throws IOException {

		StringBuffer newpath = new StringBuffer();
		if (controllerPath.isEmpty()) {
			controllerPath = "/.*";
			newpath.append(controllerPath);
		} else {

			newpath.append("/").append(controllerPath).append("/.*");
		}
		System.out.println(newpath);
		return new SwaggerSpringMvcPlugin(this.springSwaggerConfig).apiInfo(
				apiInfo()).includePatterns(newpath.toString());
	}

	/**
	 * API Info as it appears on the swagger-ui page
	 * 
	 */
	private ApiInfo apiInfo() {
		if (apiName.isEmpty()) {
			apiName = "Please Configure swagger.api.name Property In application.yml File";
		}
		if (apiDescription.isEmpty()) {
			apiDescription = "Please Configure swagger.api.description Property In application.yml File";
		}

		ApiInfo apiInfo = new ApiInfo(apiName, apiDescription, " ", "cognizant",
				" ", " ");
		return apiInfo;
	}
}