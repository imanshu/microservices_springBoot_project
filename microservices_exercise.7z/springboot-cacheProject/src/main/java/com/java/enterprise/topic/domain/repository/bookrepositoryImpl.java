package com.java.enterprise.topic.domain.repository;

import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.stereotype.Component;

import com.java.enterprise.topic.domain.topic;

@Component
@EnableCaching
public class bookrepositoryImpl implements topicRepository{

	@Cacheable(value = "USER_CACHE_REPOSITORY", key = "#id")
	@Override
	public topic getById(String id) {
		//simulateSlowService();
		return new topic(1, "some topic", "topic description");
	}
	
	private void simulateSlowService() {
        try {
            long time = 5000L;
            Thread.sleep(time);
        } catch (InterruptedException e) {
            throw new IllegalStateException(e);
        }
    }
	

	@Caching(put = {
			@CachePut(value = "USER_CACHE_REPOSITORY", key = "#newTopic.getId()")})
	@Override
	public topic saveTopic(topic newTopic) {
		// TODO Auto-generated method stub
		topic newtopic = new topic();
		newtopic.setId(2);
		newtopic.setName("somename");
		newtopic.setDescription("description");
		
		
		return null;
	}
}
