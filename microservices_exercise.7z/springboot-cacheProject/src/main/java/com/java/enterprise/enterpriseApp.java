package com.java.enterprise;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;

import com.java.enterprise.topic.domain.repository.topicRepository;

@SpringBootApplication
@ComponentScan("com.java.enterprise.**")
public class enterpriseApp implements CommandLineRunner{
	
	private static final Logger logger = LoggerFactory.getLogger(enterpriseApp.class);
	@Autowired
	private final topicRepository repo;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(enterpriseApp.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		/*
		logger.info("no.1 " + repo.getById("1") );
		logger.info("no.2 " + repo.getById("2") );
		logger.info("no.3 " + repo.getById("1") );
		logger.info("no.4 " + repo.getById("2") );
		logger.info("no.5 " + repo.getById("3") );
		*/
		System.out.print(repo.getById("1"));
	}

	public enterpriseApp(topicRepository repo) {
		super();
		this.repo = repo;
	}


}
