package com.java.enterprise.topic.domain.repository;


import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.cache.annotation.Caching;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.java.enterprise.topic.domain.topic;

@Repository
@Component
public interface topicRepository {
	@Cacheable(value = "USER_CACHE_REPOSITORY", key = "#id")
	topic getById(String id);
	
	@Caching(put = {
			@CachePut(value = "USER_CACHE_REPOSITORY", key = "#newTopic.getId()")})
	topic saveTopic(topic newTopic );

}
