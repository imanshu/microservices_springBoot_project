package com.example.redis.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class MessageService {
	
	
	@Cacheable
	public String getMessage(String msg) {
		
		return msg;
	}

}
