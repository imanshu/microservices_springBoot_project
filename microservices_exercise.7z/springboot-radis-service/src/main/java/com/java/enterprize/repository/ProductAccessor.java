package com.java.enterprize.repository;

import org.springframework.cache.annotation.Cacheable;

import com.datastax.driver.mapping.annotations.Accessor;
import com.datastax.driver.mapping.annotations.Query;
import com.java.enterprize.domain.Product;

@Accessor
public interface ProductAccessor {
	
	@Query("SELECT * FROM apikeyspace.products where id = ?")
	@Cacheable("Product")
	Product getById(int id);
	
}
