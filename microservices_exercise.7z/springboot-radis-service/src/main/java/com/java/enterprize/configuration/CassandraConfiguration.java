package com.java.enterprize.configuration;

import java.net.InetAddress;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "cassandra")
public class CassandraConfiguration {
	
	private String keypacename;
	
	private List<InetAddress> contactPoints;

	public String getKeypacename() {
		return keypacename;
	}

	public void setKeypacename(String keypacename) {
		this.keypacename = keypacename;
	}

	public List<InetAddress> getContactPoints() {
		return contactPoints;
	}

	public void setContactPoints(List<InetAddress> contactPoints) {
		this.contactPoints = contactPoints;
	}
	
}
