package com.java.enterprize.service;

import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class SampleService {
	
	@Cacheable(value ="messageCache")
	public String getMessage(String msg) {
	
		return msg;
	}

}
