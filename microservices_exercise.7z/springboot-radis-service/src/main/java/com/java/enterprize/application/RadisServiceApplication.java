package com.java.enterprize.application;

import java.util.List;

import org.apache.catalina.core.ApplicationContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import com.java.enterprize.configuration.RadisConfiguration;
import com.java.enterprize.domain.Product;
import com.java.enterprize.repository.ProductRepository;
import com.java.enterprize.service.SampleService;

import redis.clients.jedis.Jedis;

@SpringBootApplication
@EnableCaching
public class RadisServiceApplication implements CommandLineRunner{
	private static final Logger logger = LoggerFactory.getLogger(RadisServiceApplication.class);
	
	//@Autowired
	//private ProductRepository repo;
	//@Autowired
	//private StringRedisTemplate template;
	

	//@Autowired
	//public SampleService service;
	
	
	public static void main(String[] args) {
		
		//AnnotationConfigApplicationContext context = new  AnnotationConfigApplicationContext(RadisConfiguration.class);
		//SampleService service = context.getBean(SampleService.class);
		

		SpringApplication.run(RadisServiceApplication.class, args);
		
	}
	
	
	
   // this is just for check and testing 
	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		logger.info("connection");
		AnnotationConfigApplicationContext context = new  AnnotationConfigApplicationContext(RadisConfiguration.class);
		SampleService service = context.getBean(SampleService.class);
		
		//logger.info("get data ::::"  + repo.getById(1));
		/*
		ValueOperations<String, String> ops = this.template.opsForValue();
		String key = "redis.test";
		if (!this.template.hasKey(key)) {
			ops.set(key, "foo");
			ops.get("redis.test");
			ops.get(key.toString());
			logger.info(ops.get("redis.test"));
		}
		ValueOperations<String, String> ops1 = this.template.opsForValue();
		
		Product product = new Product(1,"a","b","c");
		//logger.info(product.toString());
		//logger.info("Found key " + key + ", value=" + ops.get(key));
		//logger.info(template.toString());
		 * */
		
		logger.info("message is : " + service.getMessage("hi redis"));
		logger.info("message is : " + service.getMessage("hi redis"));
		logger.info("message is : " + service.getMessage("hi redis"));
		logger.info("message is : " + service.getMessage("hi redis"));
		
	}

}
