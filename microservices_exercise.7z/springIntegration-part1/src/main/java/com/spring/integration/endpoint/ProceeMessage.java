package com.spring.integration.endpoint;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.stereotype.Component;

import com.spring.integration.msg.HelloMsg;

@Component
public class ProceeMessage {
	private Logger log = LoggerFactory.getLogger(this.getClass().getName());
	
	private WelcomeEndpoint welcome;
	
	public Message<?> processMsg(){
		
        String strMsg = "Hello " + "anshu" + "!";;
        
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
        LocalDateTime now = LocalDateTime.now();
        String currentTime = dtf.format(now);
        
        HelloMsg returnMsg = new HelloMsg(strMsg, currentTime);
        log.info("Request with message = some");
        log.info("Request with message = " + 
        MessageBuilder.withPayload(returnMsg)
        .setHeader("http_statusCode", HttpStatus.OK)
        .build().toString());
		
		return  MessageBuilder.withPayload(returnMsg)
		        .setHeader("http_statusCode", HttpStatus.OK)
		        .build();
	}
	

}
