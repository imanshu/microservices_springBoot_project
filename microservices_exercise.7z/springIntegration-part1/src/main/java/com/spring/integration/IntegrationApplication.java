package com.spring.integration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

@SpringBootApplication
@ComponentScan(basePackages = {"com.spring.integration.endpoint", "com.spring.integration.msg"})
@ImportResource("classpath:integration.xml")
@EnableAutoConfiguration
public class IntegrationApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(IntegrationApplication.class,args);

	}

}
