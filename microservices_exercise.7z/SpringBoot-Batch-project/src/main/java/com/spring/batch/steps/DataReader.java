package com.spring.batch.steps;


import org.springframework.batch.item.ItemReader;

public class DataReader implements ItemReader<String>{
	
	
	private String[] messages = { "helloo",
			"hiiiiii",
			"byeeeee" };

	private int count = 0;

	@Override
	public String read() {

		if (count < messages.length) {
			return messages[count++];
		} else {
			count = 0;
		}
		return null;
	}

}
