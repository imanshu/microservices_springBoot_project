package com.spring.batch.steps;

import org.springframework.batch.item.ItemProcessor;

public class DataProcessor implements ItemProcessor<String,String> {
	
	
	@Override
	public String process(String data) {
		
		System.out.println("data is processed");
		return data.toUpperCase();
		
		
	}

}
