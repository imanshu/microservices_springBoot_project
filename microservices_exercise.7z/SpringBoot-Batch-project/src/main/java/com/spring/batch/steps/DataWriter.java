package com.spring.batch.steps;

import java.util.List;

import org.springframework.batch.item.ItemWriter;

public class DataWriter implements ItemWriter<String>{

	@Override
	public void write(List<? extends String> items) throws Exception {
		// TODO Auto-generated method stub
		for(String data: items) {
			System.out.println("data is written :" + data);
		}
		
	}
	
	

}
