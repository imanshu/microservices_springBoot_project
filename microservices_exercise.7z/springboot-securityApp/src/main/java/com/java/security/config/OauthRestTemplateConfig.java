package com.java.security.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.DefaultOAuth2ClientContext;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.security.oauth2.client.resource.OAuth2ProtectedResourceDetails;
import org.springframework.security.oauth2.client.token.AccessTokenRequest;
import org.springframework.security.oauth2.client.token.DefaultAccessTokenRequest;
import org.springframework.security.oauth2.client.token.grant.password.ResourceOwnerPasswordResourceDetails;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableOAuth2Client;

@EnableOAuth2Client 
@Configuration
public class OauthRestTemplateConfig {
	
	    @Bean
	    protected OAuth2ProtectedResourceDetails resource() {

	        ResourceOwnerPasswordResourceDetails resource = new ResourceOwnerPasswordResourceDetails();

	        List scopes = new ArrayList<String>(2);
	        scopes.add("write");
	        scopes.add("read");
	        resource.setAccessTokenUri("http://localhost:1000/oauth/token");
	        resource.setClientId("my-clients");
	        resource.setClientSecret("secret");
	        resource.setGrantType("password");
	        resource.setScope(scopes);

	        resource.setUsername("user");
	        resource.setPassword("password");

	        return resource;
	    }
	    
	    @Bean
	    public OAuth2RestOperations restTemplate() {
	        AccessTokenRequest atr = new DefaultAccessTokenRequest();
	        DefaultOAuth2ClientContext clientContext = new DefaultOAuth2ClientContext();

	        return new OAuth2RestTemplate(resource(), new DefaultOAuth2ClientContext(atr));
	    }


}
