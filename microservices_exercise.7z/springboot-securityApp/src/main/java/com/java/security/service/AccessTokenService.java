package com.java.security.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestOperations;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.stereotype.Service;

@Service("token-service")
@SuppressWarnings("unchecked")
public class AccessTokenService {
	
	@Autowired
    private OAuth2RestOperations restTemplate;

    public OAuth2AccessToken MyService() {
    	System.out.print(restTemplate.getResource().toString());
        return restTemplate.getAccessToken();
    }
    
    public String sourceInfo() {
    	
    	return restTemplate.getResource().toString();
    }

}
