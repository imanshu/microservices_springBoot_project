package com.java.elastic.controller;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApplicationController {

}
