package com.java.redis.domain;

import lombok.Data;

@Data
public class Cart {
	
	private static final long serialVersionUID = -3140123863002731923L;

	String firstName;
	String lastName;
	int noOfItem;

}
