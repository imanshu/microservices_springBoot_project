package com.java.redis.service;

import java.util.Map;

public interface SessionService {
	
	boolean updateProfileInfo(Map<String, String> queryParameters);

	boolean updateCartInfo(Map<String, String> queryParameters);



}
