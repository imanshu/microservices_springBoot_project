package com.java.redis.config;

import org.apache.catalina.util.SessionConfig;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.serializer.Jackson2JsonRedisSerializer;
import org.springframework.data.redis.serializer.RedisSerializer;

import ch.qos.logback.classic.Logger;

@Configuration
public class SessionConfiguration {
	public static Logger logger = (Logger) LoggerFactory.getLogger(SessionConfig.class);
	
	  @Bean(name = {"defaultRedisSerializer"})
	    RedisSerializer<Object> defaultRedisSerializer(){
	        return new Jackson2JsonRedisSerializer<>(Object.class);
	  }

}
