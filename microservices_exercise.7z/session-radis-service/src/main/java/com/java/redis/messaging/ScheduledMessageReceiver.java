package com.java.redis.messaging;

import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Scheduled;

import com.java.redis.config.RedisConfiguration;
import com.java.redis.service.RedisDataService;

import ch.qos.logback.classic.Logger;

public class ScheduledMessageReceiver {
	
	
	Logger logger = (Logger) LoggerFactory.getLogger(ScheduledMessageReceiver.class);

	@Autowired
	private RedisTemplate<String, Object> redis;

	@Autowired
	private RedisDataService dataService;

	private String queueName;

	public ScheduledMessageReceiver(String queueName) {
		this.queueName = queueName;
	}

	@Scheduled(fixedDelay = 1000L)
	public void recieveMessage() {

		ListOperations<String, Object> lops = redis.opsForList();

		lops.rightPopAndLeftPush(queueName, RedisConfiguration.getWorkerQueueName());

		ListOperations<String, Object> workerData = redis.opsForList();

		while (workerData.size(RedisConfiguration.getWorkerQueueName()) > 0) {
			dataService.saveData((Map<String, Map<String, Object>>) workerData
					.rightPop(RedisConfiguration.getWorkerQueueName()));
		}

	}


}
