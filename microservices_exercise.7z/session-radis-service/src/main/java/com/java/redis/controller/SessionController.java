package com.java.redis.controller;

import java.util.Map;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.java.redis.service.SessionService;

import ch.qos.logback.classic.Logger;

public class SessionController {
	
	
	Logger logger = (Logger) LoggerFactory.getLogger(SessionController.class);

	@Autowired
	private StringRedisTemplate redis;
	
	@Autowired
	private SessionService service;
	
	@RequestMapping(value = "/sessions", method = RequestMethod.GET)
	public @ResponseBody void getSessions() {		
	}
	
	 @RequestMapping(value="/session/{id}",method = RequestMethod.GET)       
     public String getSession(@PathVariable("id") String sessionId) {
		 //HashOperations<String, String> operations = this.redis.opsForHash();
		 HashOperations<String, Object, Object> ops = redis.opsForHash(); 
	     logger.info("incoming key is " + sessionId);
	     Object value = ops.values("spring:session:sessions:"
	     		+ sessionId);	     	
	     Object firstName = ops.get("spring:session:sessions:"
		     		+ sessionId,  "sessionAttr:firstName");
	     Object lastName = ops.get("spring:session:sessions:"
		     		+ sessionId,  "sessionAttr:lastName");
	     logger.info("value form redis is " + value + " " + firstName.toString() + " " + lastName.toString());
	     return value.toString();
     }

	 
	 @RequestMapping(value = "/profileInfo", method = RequestMethod.POST)
		public  @ResponseBody boolean updateProfileInfo(@RequestBody Map<String, String> queryParameters) {			
			logger.info("Inside the update controller");
			if (queryParameters.keySet().size() > 0) {
				logger.debug("incoming query is " + queryParameters.keySet()
						+ queryParameters.get(queryParameters.keySet().iterator().next()));
			}		
			boolean isSuccess = service.updateProfileInfo(queryParameters);
			logger.info("session service returned " + isSuccess);		
			return isSuccess;
		}
	 
	 @RequestMapping(value = "/cartInfo", method = RequestMethod.POST)
		public  @ResponseBody boolean updateCartInfo(@RequestBody Map<String, String> queryParameters) {			
			logger.info("Inside the update controller");
			if (queryParameters.keySet().size() > 0) {
				logger.debug("incoming query is " + queryParameters.keySet()
						+ queryParameters.get(queryParameters.keySet().iterator().next()));
			}		
			boolean isSuccess = service.updateCartInfo(queryParameters);
			logger.info("session service returned " + isSuccess);		
			return isSuccess;
		}


}
