package com.java.redis.service;

import java.util.Map;

public class SessionServiceImpl implements SessionService{

	@Override
	public boolean updateProfileInfo(Map<String, String> queryParameters) {
		// TODO Auto-generated method stub
		return true;
	}

	@Override
	public boolean updateCartInfo(Map<String, String> queryParameters) {
		// TODO Auto-generated method stub
		return true;
	}

}
