package com.java.redis.service;

import java.util.Map;

public class RedisDataServiceImpl implements RedisDataService{

	@Override
	public boolean saveData(Map<String, Map<String, Object>> sessionData) {
		// TODO Auto-generated method stub
		return true;
	}

}
