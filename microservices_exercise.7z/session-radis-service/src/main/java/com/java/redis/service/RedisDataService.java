package com.java.redis.service;
import java.util.Map;


public interface RedisDataService {
	
	public boolean saveData(Map<String,Map<String,Object>> sessionData);


}
