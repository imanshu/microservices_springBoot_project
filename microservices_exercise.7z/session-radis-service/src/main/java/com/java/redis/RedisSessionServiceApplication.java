package com.java.redis;

import java.awt.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.core.ValueOperations;

import redis.clients.jedis.Jedis;


@SpringBootApplication
public class RedisSessionServiceApplication implements CommandLineRunner{
	
	private static final Logger logger = LoggerFactory.getLogger(RedisSessionServiceApplication.class);
	@Autowired
	private StringRedisTemplate template;

	@Override
	public void run(String... args) throws Exception {
		ValueOperations<String, String> ops = this.template.opsForValue();
		String key = "redis.test";
		if (!this.template.hasKey(key)) {
			ops.set(key, "foo");
		}
		logger.info("Found key " + key + ", value=" + ops.get(key));
		logger.info(template.toString());
	}
	
	
	public static void main(String[] args) {
		
		SpringApplication.run(RedisSessionServiceApplication.class, args);
		
		Jedis jedis = new Jedis("localhost"); 
	      System.out.println("Connection success");
	      //jedis.set("key1", "value1");
	      logger.info(jedis.get("key1"));
	
		
		
	}
}
