package com.swaager.ex.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import io.swagger.annotations.Api;

@RestController
@Api(value = "user-service" , description = "sample service for user data")
public class HelloController {
	
	
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String helloMessage() {
		
		return "hello swagger";
	}

}
