package com.swaager.ex.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.google.common.base.Predicates;

import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
import static springfox.documentation.builders.PathSelectors.regex;

@Configuration
@EnableSwagger2
@ComponentScan("com.swaager.ex")
public class SwaggerConfig {
	
	public Docket userApi() {
		return new Docket(DocumentationType.SWAGGER_2)
				.groupName("business-api")
				.select()
				.apis(Predicates.not(RequestHandlerSelectors.basePackage("org.springframework.http")))
				.paths(Predicates.not(PathSelectors.regex("/error.*")))
				.paths(regex("/api/.*"))
				.build()
				.apiInfo(apiInfo());
		
	}
	
	public ApiInfo apiInfo() {
		ApiInfo apiinfo = new ApiInfo("Spring Boot REST API",
                "Spring Boot REST API for Online Store",
                "1.0",
                "Terms of service",
                new Contact("John Thompson", "https://springframework.guru/about/", "john@springfrmework.guru"),
                "Apache License Version 2.0",
                "https://www.apache.org/licenses/LICENSE-2.0");
		ApiInfo apiinfonew = new ApiInfoBuilder().title("user data api").description("just user inforamation basic").contact(new Contact("anshu" , "anshu@cognizant.com","chennai")).license("LICENSE 1.0.0").build();
		return apiinfo;
	}

}
