# SpringSecurityApp
Spring Security for Spring MVC 4 Application Simple Example using Spring Boot

Step by Step tutorial with demo at http://www.programming-free.com/2015/08/spring-security-for-spring-mvc-4.html
