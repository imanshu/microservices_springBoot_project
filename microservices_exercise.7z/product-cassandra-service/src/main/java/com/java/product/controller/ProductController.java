package com.java.product.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.metrics.GaugeService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.java.product.domain.Product;
import com.java.product.service.ProductService;


@RestController
public class ProductController {
	
	@Autowired
	private ProductService service;
	

    //@Autowired
    //private GaugeService gauges;

	
	@RequestMapping(value = "/product/v1/{id}" ,method = RequestMethod.GET)
	public Product getProductById(@PathVariable("id") String id) {
		
        //this.gauges.submit("timer.test.value", Math.random()*1000 + 1000);
		return service.getById(id);	
	}
	
	@RequestMapping(value = "/product/v1" ,method = RequestMethod.POST)
	public void saveProduct(@RequestBody Product product) {

        //this.gauges.submit("timer.test.value", Math.random()*1000 + 1000);
		service.saveProduct(product);
		
	}
	

}
	
