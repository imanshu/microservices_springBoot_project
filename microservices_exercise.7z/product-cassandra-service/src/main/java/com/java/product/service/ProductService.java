package com.java.product.service;

import org.springframework.stereotype.Service;

import com.java.product.domain.Product;

@Service
public interface ProductService {
	
	Product getById(String id);
    
    void saveProduct(Product product);

}
