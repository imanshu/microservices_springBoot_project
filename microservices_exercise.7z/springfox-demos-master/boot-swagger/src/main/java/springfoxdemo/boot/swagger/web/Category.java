package springfoxdemo.boot.swagger.web;

public enum Category {
    ONE,
    TWO,
    THREE
}
