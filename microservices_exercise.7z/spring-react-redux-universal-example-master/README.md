# spring-react-redux-universal-example
Example of The Universal Web Application using Spring Boot + React + Redux.
