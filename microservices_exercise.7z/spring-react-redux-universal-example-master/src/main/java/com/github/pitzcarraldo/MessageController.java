package com.github.pitzcarraldo;

import org.springframework.web.bind.annotation.RestController;

/**
 * @author Alan(Minkyu Cho)
 */
@RestController
public class MessageController {
}
