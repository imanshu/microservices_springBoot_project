export default function version(state = 0, action) {
    return state;
}