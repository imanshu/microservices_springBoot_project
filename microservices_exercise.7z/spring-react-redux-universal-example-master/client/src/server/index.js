var babelConfig = require('../../babel.config');
require('babel/register')(babelConfig);
require('./server');