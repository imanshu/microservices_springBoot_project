module.exports = {
	"stage": 0,
	"optional": "runtime",
	"loose": "all",
	"plugins": [
		"typecheck"
	],
	"env": {
		"development": {
			"plugins": [
				"react-transform"
			],
			"extra": {
				"react-transform": {
					"transforms": [{
						"transform": "react-transform-catch-errors",
						"imports": [
							"react",
							"redbox-react"
						]
					}]
				}
			}
		}
	}
};