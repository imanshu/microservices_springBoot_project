package com.java.enterprise.customer.domain;

import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.springframework.data.cassandra.mapping.Column;
import org.springframework.data.cassandra.mapping.PrimaryKey;

import com.datastax.driver.mapping.annotations.PartitionKey;
import com.netflix.governator.annotations.binding.Primary;


@Table(name = "customer")
public class Customer {
	
	@PartitionKey
	@Column
	int id;
	
	@Column
	String name;

/**
 * @param id
 * @param name
 */
public Customer(int id, String name) {
	super();
	this.id = id;
	this.name = name;
}


public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

@Override
public String toString() {
	return "Customer [id=" + id + ", name=" + name + "]";
}


}
