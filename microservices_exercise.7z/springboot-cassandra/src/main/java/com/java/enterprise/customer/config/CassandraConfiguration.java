package com.java.enterprise.customer.config;

import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "spring.data.cassandra")
public class CassandraConfiguration {
	
	private String keyspaceName;

	private List<String> contactPoints;
	
	public String getKeyspaceName() {
		return keyspaceName;
	}
	public void setKeyspaceName(String keyspaceName) {
		this.keyspaceName = keyspaceName;
	}
	public List<String> getContactPoints() {
		return contactPoints;
	}
	public void setContactPoints(List<String> contactPoints) {
		this.contactPoints = contactPoints;
	}

	public CassandraConfiguration(String keyspaceName, List<String> contactPoints) {
		super();
		this.keyspaceName = keyspaceName;
		this.contactPoints = contactPoints;
	}
	public CassandraConfiguration() {
		super();
	}

}
