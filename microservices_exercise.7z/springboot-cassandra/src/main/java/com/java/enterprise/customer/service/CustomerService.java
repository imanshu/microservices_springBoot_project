package com.java.enterprise.customer.service;

import com.java.enterprise.customer.domain.Customer;

public interface CustomerService {
	
	public Customer getById(int id);
	public boolean saveCustomer(Customer customer);

}
