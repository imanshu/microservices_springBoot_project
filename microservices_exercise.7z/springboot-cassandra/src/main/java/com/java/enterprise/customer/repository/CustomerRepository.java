package com.java.enterprise.customer.repository;

import org.springframework.data.cassandra.repository.Query;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.repository.CrudRepository;

import com.datastax.driver.mapping.annotations.Accessor;
import com.java.enterprise.customer.domain.Customer;


public interface CustomerRepository extends CrudRepository<Customer, Integer> {
	
	@Query("Select * from customer where id = ?1")
	public Customer findById(int id); 
	
}
