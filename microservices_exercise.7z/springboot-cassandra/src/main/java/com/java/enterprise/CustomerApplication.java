package com.java.enterprise;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

import com.java.enterprise.customer.domain.Customer;
import com.java.enterprise.customer.repository.CustomerRepository;

@SpringBootApplication
public class CustomerApplication implements CommandLineRunner {
	
	@Autowired
	CustomerRepository repository;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		SpringApplication.run(CustomerApplication.class, args);

	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		this.repository.deleteAll();
		this.repository.save(new Customer(1, "Alice"));
		this.repository.save(new Customer(2, "Bob"));

		System.out.println("Customers :");
		for (Customer customer : this.repository.findAll()) {
			System.out.println(customer);
		}
		System.out.println();
		
		System.out.println(this.repository.findById(1));
		System.out.println(this.repository.findById(2));

		}


}
