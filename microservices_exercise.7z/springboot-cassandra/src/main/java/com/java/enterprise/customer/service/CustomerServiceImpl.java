package com.java.enterprise.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.enterprise.customer.domain.Customer;
import com.java.enterprise.customer.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepository repository;

	@Override
	public Customer getById(int id) {
		// TODO Auto-generated method stub
		return (Customer) repository.findOne(id);
	}

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		repository.save(customer);
		return true;
	}

}
