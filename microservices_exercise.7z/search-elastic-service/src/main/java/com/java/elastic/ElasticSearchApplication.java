package com.java.elastic;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.elasticsearch.client.transport.TransportClient;
import org.elasticsearch.common.settings.Settings;
import org.elasticsearch.common.transport.InetSocketTransportAddress;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
public class ElasticSearchApplication {
	
	public static void main(String[] args) throws UnknownHostException {
		
		//SpringApplication.run(ElasticSearchApplication.class, args);
		
		Settings settings = Settings.builder().put("cluster.name", "product-search").build();
        TransportClient client = new TransportClient.Builder().settings(settings).build();
        client.addTransportAddress(new InetSocketTransportAddress(InetAddress.getByName("localhost"), 9300));
        System.out.println(client.connectedNodes());
		
	}
}
