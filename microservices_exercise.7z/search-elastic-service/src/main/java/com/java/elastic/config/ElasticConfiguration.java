package com.java.elastic.config;

import java.net.InetAddress;
import java.util.List;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import lombok.Getter;
import lombok.Setter;

@Configuration
@EnableConfigurationProperties
@ConfigurationProperties(prefix = "elastic")
public class ElasticConfiguration {
	
	private List<InetAddress> contactPoints;
	private String clusterName;
	private int port;
	
	public List<InetAddress> getContactPoints() {
		return contactPoints;
	}
	public void setContactPoints(List<InetAddress> contactPoints) {
		this.contactPoints = contactPoints;
	}
	public String getClusterName() {
		return clusterName;
	}
	public void setClusterName(String clusterName) {
		this.clusterName = clusterName;
	}
	public int getPort() {
		return port;
	}
	public void setPort(int port) {
		this.port = port;
	}


}
