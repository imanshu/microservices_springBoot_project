package com.java.elastic.service;

import static org.elasticsearch.index.query.QueryBuilders.commonTermsQuery;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.elastic.config.ElasticClient;
import com.java.elastic.domain.Product;

@Service("SearchService")
public class SearchServiceImpl implements SearchService{
	
	
	@Autowired
	ElasticClient client;

	@Override
	public List<Product> getProducts(Map<String, String> queryParameters) {
		// TODO Auto-generated method stub
		
		List<Product> products = new ArrayList<Product>();
		
		String query = queryParameters.get("q");
		String searchType = queryParameters.get("type");
		
		String fieldType = "name";
		QueryBuilder qb ;
		
		qb = commonTermsQuery(fieldType,query);
		
		SearchResponse response = client.getClient().prepareSearch("products").setTypes("product").setSize(200).setQuery(qb).execute().actionGet();
		
		
		List<Product> productsList = new ArrayList<Product>();
		for (SearchHit Hit : response.getHits().getHits()) {
			
			Map<String, Object> doc = Hit.getSource();
			
			Product product = new Product();
			
			product.setId(Integer.valueOf(doc.get("id").toString()));
			product.setName(doc.get("name").toString());
			product.setReviews(doc.get("reviews").toString());
			product.setUnitPrice(doc.get("unitPrice").toString());
			
			productsList.add(product);
			
		}
		return productsList;
	}

	@Override
	public List<Product> getDefaultResult() {
		// TODO Auto-generated method stub
		SearchResponse response = client.getClient().prepareSearch("products").setTypes("product").setSize(200).execute().actionGet();
		List<Product> productsList = new ArrayList<Product>();   
		for (SearchHit Hit : response.getHits().getHits()) {
			
			Map<String, Object> doc = Hit.getSource();
			
			Product product = new Product();
			
			product.setId(Integer.valueOf(doc.get("id").toString()));
			product.setName(doc.get("name").toString());
			product.setReviews(doc.get("reviews").toString());
			product.setUnitPrice(doc.get("unitPrice").toString());
			productsList.add(product);
		}
		
		return productsList;
	}
	
}
