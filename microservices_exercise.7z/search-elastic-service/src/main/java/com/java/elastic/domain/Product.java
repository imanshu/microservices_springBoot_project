package com.java.elastic.domain;


public class Product {
	
		private int id;
	
		private String name;

		private String unitPrice;

		private String reviews;

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getUnitPrice() {
			return unitPrice;
		}

		public void setUnitPrice(String unitPrice) {
			this.unitPrice = unitPrice;
		}

		public String getReviews() {
			return reviews;
		}

		public void setReviews(String reviews) {
			this.reviews = reviews;
		}

		public Product(int id, String name, String unitPrice, String reviews) {
			super();
			this.id = id;
			this.name = name;
			this.unitPrice = unitPrice;
			this.reviews = reviews;
		}

		public Product() {
			// TODO Auto-generated constructor stub
		}


}
