package com.java.elastic.repository;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchCrudRepository;

import com.java.elastic.domain.User;

public interface UserRepository extends ElasticsearchCrudRepository<User, Serializable> {
	
	List<User> findById(Long id);
	List<User> findByName(String name);
}
