package com.java.elastic.load;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.elasticsearch.annotations.Document;
import org.springframework.data.elasticsearch.core.ElasticsearchOperations;
import org.springframework.stereotype.Component;

import com.java.elastic.domain.User;
import com.java.elastic.repository.UserRepository;


@Component
public class Loaders {
	
	    @Autowired
	    ElasticsearchOperations operations;

	    @Autowired
	    UserRepository userRepository;

	    @PostConstruct
	    @Transactional
	    public void loadAll(){

	        operations.putMapping(User.class);
	        System.out.println("Loading Data");
	        userRepository.save(getData());
	        System.out.printf("Loading Completed");

	    }

	    private List<User> getData() {
	        List<User> users = new ArrayList<>();
	        users.add(new User("anshu",123L, "developement", 50000L));
	        users.add(new User("aryan",1234L, "HR", 55000L));
	        users.add(new User("akash",1235L, "SUPPORT", 50000l));
	        return users;
	    }
		
}
