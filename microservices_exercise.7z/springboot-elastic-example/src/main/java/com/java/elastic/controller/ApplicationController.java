package com.java.elastic.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.java.elastic.domain.User;
import com.java.elastic.repository.UserRepository;

@RestController
public class ApplicationController {
	
	    @Autowired
	    UserRepository userRepository;

	    @GetMapping(value = "/name/{text}")
	    public List<User> searchName(@PathVariable final String name) {
	        return userRepository.findByName(name);
	    }
	    
	    @GetMapping(value = "/id/{id}")
	    public List<User> searchId(@PathVariable final Long id) {
	        return userRepository.findById(id);
	    }



	    @GetMapping(value = "/all")
	    public List<User> searchAll() {
	        List<User> userList = new ArrayList<>();
	        Iterable<User> useres = userRepository.findAll();
	        useres.forEach(userList::add);
	        return userList;
	    }

}
