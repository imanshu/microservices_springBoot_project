INSERT INTO USER VALUES(1, 'admin', 'admin');
INSERT INTO USER VALUES(2, 'user', 'user');