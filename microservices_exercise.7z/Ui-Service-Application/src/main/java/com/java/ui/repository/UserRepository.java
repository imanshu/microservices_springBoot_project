package com.java.ui.repository;

import org.springframework.data.repository.CrudRepository;

import com.java.ui.model.User;

public interface UserRepository extends CrudRepository<User, String> {

}
