package com.java.ui.controller;


import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.java.ui.model.User;
import com.java.ui.repository.UserRepository;
import com.java.ui.service.UserService;

@Controller
public class PageViewController {
	
	
	private Logger logger = LoggerFactory.getLogger(this.getClass().getName());
	
	@Autowired
	private UserRepository repository;
	
	@Autowired
	private UserService service;
	
	@RequestMapping(value="/register",method=RequestMethod.GET)
	public String index(Model model) {
		model.addAttribute("user", new User() );
		logger.info(model.toString());
		logger.info("serving the login page");
		return "index";
	}
	@RequestMapping(value="/register",method=RequestMethod.POST)
	public String registerprocess(@ModelAttribute User user) {
	    repository.save(user);
	    String name = user.getName();
	    User checkUser = service.getUserByName(name);
	    if (checkUser == null)
	    	return "userPage";
		logger.info("registration donw successfully" + user);
		return "user already exist";
	}

	@RequestMapping(value="/userinfo",method=RequestMethod.POST)
	public String useinfo(@ModelAttribute User user) {
	    repository.save(user);
	    String name = user.getName();
		logger.info("registration donw successfully" + user);
		return "userPage";
	}
	@RequestMapping(value="/login",method=RequestMethod.GET)
	public String login(Model model) {
		model.addAttribute("user", new User() );
		logger.info("serving the login page");
		return "index";
	}
	

}
