package com.java.ui.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.java.ui.model.User;
import com.java.ui.repository.UserRepository;

@Service
public class UserService {
	
	@Autowired
	UserRepository repository;
	
	public User getUserByName(String name) {
		return repository.findOne(name);

	}
	
	public boolean saveTopic(User user){
		boolean b = true;
		repository.save(user);
		if (user == null)
			b= false;
		return b;
		
	}

}
