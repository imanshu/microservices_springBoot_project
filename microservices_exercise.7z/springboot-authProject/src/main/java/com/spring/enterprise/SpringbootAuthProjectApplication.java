package com.spring.enterprise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAuthProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootAuthProjectApplication.class, args);
	}
}
