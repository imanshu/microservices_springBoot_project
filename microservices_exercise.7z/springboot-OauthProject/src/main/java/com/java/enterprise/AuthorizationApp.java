package com.java.enterprise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AuthorizationApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
    SpringApplication.run(AuthorizationApp.class,args);
	}

}
