package com.java.enterprise.auth.controller;


import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AouthController {
	
	@RequestMapping(path = "/account/private/{accountNo}", method =RequestMethod.GET)
	public String maincontroller(@PathVariable String accountNo) {
		
		return "account logged in with no. :" + accountNo ;
	}
	@RequestMapping(path = "/account")
	public String fallbackcontroller() {
		
		return "account logged in with no. :" ;
	}
}

