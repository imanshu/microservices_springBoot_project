package com.java.enterprise.auth.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@EnableWebSecurity
public class AuthrizationConfig extends WebSecurityConfigurerAdapter{
	
	private static final String ADMIN = "ADMIN";
	private static final String USER = "USER";

	public void config(HttpSecurity httpSecurity) {
		
		try {
			httpSecurity.authorizeRequests().antMatchers("/account/private/*").hasRole(USER).and().formLogin();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@Autowired
	public void setConfiguration(AuthenticationManagerBuilder builder) throws Exception {
		builder.inMemoryAuthentication().withUser("user").password("user").roles(USER).and().withUser("admin").password("admin").roles(USER,ADMIN);
		
	}

}
