package spring.integration.application;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ImportResource;

import spring.integration.application.service.GreeterService;

@SpringBootApplication
@ComponentScan(basePackages = {"spring.integration.application.service","spring.integration.application.controller"})
@ImportResource("classpath:integration.xml")
@EnableAutoConfiguration
public class SpringIntegrationApplicatin implements CommandLineRunner{
	private static final Logger logger = LoggerFactory.getLogger(SpringIntegrationApplicatin.class);
	
	@Autowired
	GreeterService greeterService;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    SpringApplication.run(SpringIntegrationApplicatin.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		/*
		greeterService.greet("SitaRam");
		greeterService.greet2("Hanuman");
		*/
		logger.info("service channeled");
	}

}
