package spring.integration.application.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import spring.integration.application.service.GreeterService;

@Controller
public class ApplicationController {
	
	@Autowired
	GreeterService greeterService;
	
	@RequestMapping(value = "/message/{name}" ,method=RequestMethod.GET)
	public String getMessage(@PathVariable("name") String name ) {
		//greeterService.greet(name);
		return "hello " + name; 
	}

}
