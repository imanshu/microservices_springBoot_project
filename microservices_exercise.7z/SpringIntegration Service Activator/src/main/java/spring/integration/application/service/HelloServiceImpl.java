package spring.integration.application.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service("HelloService")
@Component
public class HelloServiceImpl implements HelloService{

	@Override
	public void hello(String name) {
		// TODO Auto-generated method stub
		System.out.print("hello" + name);
		
	}

	@Override
	public String getHelloMessage(String name) {
		// TODO Auto-generated method stub
		return "HELLO " + name ;
	}

	
}
