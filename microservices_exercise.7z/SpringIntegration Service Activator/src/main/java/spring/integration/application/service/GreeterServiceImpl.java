package spring.integration.application.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import spring.integration.application.SpringIntegrationApplicatin;

@Service("GreeterService")
@Component
public class GreeterServiceImpl implements GreeterService{
	private static final Logger logger = LoggerFactory.getLogger(GreeterServiceImpl.class);
	@Autowired
	MessageChannel helloChannel;
	
	@Autowired
	HelloService helloWorldGateway;

	@Override
	public void greet(String name) {
		
		// TODO Auto-generated method stub
		System.out.println(helloChannel.send(MessageBuilder.withPayload(name).build()));
	
	}

	@Override
	public void greet2(String name) {
		// TODO Auto-generated method stub
		System.out.println(helloWorldGateway.getHelloMessage(name));
		
	}

}
