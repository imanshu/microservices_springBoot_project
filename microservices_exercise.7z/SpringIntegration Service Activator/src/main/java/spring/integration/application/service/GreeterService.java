package spring.integration.application.service;

import org.springframework.stereotype.Service;

@Service
public interface GreeterService {
	public void greet(String name);
	public void greet2(String name);

}
