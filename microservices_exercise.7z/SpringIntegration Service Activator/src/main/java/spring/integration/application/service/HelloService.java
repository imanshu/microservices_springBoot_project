package spring.integration.application.service;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Service
@Component
public interface HelloService {

	 public void hello(String name);

	 public String getHelloMessage(String string);
}
