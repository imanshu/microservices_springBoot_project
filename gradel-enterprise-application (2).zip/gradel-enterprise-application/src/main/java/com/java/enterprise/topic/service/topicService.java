package com.java.enterprise.topic.service;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.CachePut;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.java.enterprise.topic.domain.topic;
import com.java.enterprise.topic.domain.repository.topicRepository;

@Service
public class topicService {
	
    @Autowired
	private topicRepository repository;
	List<topic> topics = new ArrayList<>(Arrays.asList(
			new topic(1,"java","java description"),
			new topic(2,"spring","spring description"),
			new topic(3,"spring MVC","spring MVC description")
			));
	
	@Cacheable("books")
	public List<topic> getAllToipcs() {
		
		//return topics;
		List<topic> topicList = new ArrayList<topic>();
		repository.findAll().forEach(topicList::add);
		return topicList;
	}

	public topic getTopicById(int id) {
		/**
		if (topics.stream().filter(t -> t.getId() == id ).count() != 0)
			return topics.stream().filter(t -> t.getId() == id ).findFirst().get();
		else
			System.out.println("no such topic exist");
		return topics.stream().filter(t -> t.getId() == id ).findFirst().get();
		**/
		return repository.findOne(id);

	}
	

	public boolean saveTopic(topic topic){
		boolean b = true;
		repository.save(topic);
		if (topic == null)
			b= false;
		return b;
		
	}
	
	@CachePut("books")
	public boolean updateTopic(topic topic) {
		boolean b = true;
		repository.save(topic);
		if (topic == null)
			b= false;
		return b;
	}
	
}
