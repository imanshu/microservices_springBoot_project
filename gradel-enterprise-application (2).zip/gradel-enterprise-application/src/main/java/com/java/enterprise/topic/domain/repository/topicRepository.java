package com.java.enterprise.topic.domain.repository;


import org.springframework.data.repository.CrudRepository;

import com.java.enterprise.topic.domain.topic;
public interface topicRepository extends CrudRepository<topic, Integer> {

}
